<?
/*   SPACENINJA IMAGE VIEWER

Use as the index file in a directory containing images,
and this file will display all the images in the directory
at full size, along with their filename.

*/
?>

<html>
<head><title>Space Ninja Image Directory Viewer</title></head>
<body>

<center>
<h3>Space Ninja Image Directory Viewer</h3>

<?

$dh = opendir(".");
while ($f = readdir( $dh ) ) {
	if (ereg( "(\.gif|\.jpg)", $f ) )
		show ( $f );
}

function show ($f) {
	echo "<img src=\"$f\"><BR><b>$f</b><p>";
}

?>

</center>

</body></html>