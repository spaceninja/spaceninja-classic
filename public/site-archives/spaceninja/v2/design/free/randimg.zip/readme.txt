SPACENINJA RANDOM IMAGE SCRIPT

Requirements: PHP3

Simple Instructions:
1. place the images you wish to randomize in a subdirectory.
2. make sure the page that will have the random images is using the .php extention.
3. place the following at the very top of the file:
	<? include("randimg.php"); ?>
4. place the following at the location you wish the images to appear:
	<? random_image("SUBDIRECTORY"); ?>
	where SUBDIRECTORY is the directory with your images.

Advanced Instructions:
If you need to use tags with your images, such as BORDER=0 or WIDTH=X, etc, do this.
1. follow steps 1-3 above.
2. place the following at the location you wish the images to appear:
	<? random_image_tag("SUBDIRECTORY", "TAGS"); ?>
	where SUBDIRECTORY is the directory with your images, and TAGS is any extra attributes to be added to the IMG tag.
