SPACENINJA RANDOM QUOTE SCRIPT

Requirements: PHP3

Instructions:
1. place the quotes you wish to randomize in a single text file.
2. make sure the page that will have the random quotes is using the .php extention.
3. place the following at the very top of the file:
	<? include("randquote.php"); ?>
4. place the following at the location you wish the images to appear:
	<? echo quotefrom("QUOTEFILE.TXT"); ?>
	where QUOTEFILE.TXT is the text file with your quotes.