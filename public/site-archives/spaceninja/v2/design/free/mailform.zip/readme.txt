SPACE NINJA EMAIL FORM

Requirements: PHP3

Instructions:
1. Open mailform.php and look for the line:
	$to = "YOURNAME@YOURSITE.COM";
2. Change "YOURNAME@YOURSITE.COM" to the email address you
	would like the form to send mail to.
3. From anywhere on your website, link to this file, and
	your visitors will be able to send you emails without
	needing to open a mail program. The form gathers their
	name and email address, along with a subject for the
	email, and the actual message. When they press the
	submit button, the form sends an email to the address
	specified in the $to variable.