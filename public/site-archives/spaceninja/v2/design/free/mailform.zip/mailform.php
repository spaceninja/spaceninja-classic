<html><head><title>Space Ninja Email Form</title></head>
<body bgcolor=white text=black link=blue alink=red vlink=purple>

<?
// SendEmail adds the Sender's name to the Email Body, and sends the Email.
function SendEmail () {
	global $name;
	global $email;
	global $subject;
	global $body;
	$name = stripslashes($name);
	$email = stripslashes($email);
	$subject = stripslashes($subject);
	$body = stripslashes($body);
	$from = "$name <$email>";

	$to = "YOURNAME@YOURSITE.COM";

	if (mail($to, $subject, $body, "From: $from")) {
		print ("<b>Your email has been sent successfully!</b>\n");
	} else {
		print ("<b>Your email was not successfully sent due to a server error!</b>\n");
	}
}

// HandleForm will take the information from the form, verify the MailFrom address, and call the SendEmail function.
function HandleForm () {
	global $email;
	$Pattern = ".+@.+\..+";
	if (eregi($Pattern, $email)) {
		SendEmail ();
	} else {
		print ("<i>Please enter a valid email address!</i><p>\n");
	}
}


// This conditional determines whether to handle the form, depending on whether or not $BeenSubmitted is TRUE.
if ($BeenSubmitted) {
	HandleForm();
	print "<hr><p>\n";
}

?>

<b>Fill out this form to send me email!
<form action=email.php method=post>
<table border=0>
<tr><td align=right>Your name: </td><td>
	<input name="name" size=65></td></tr>
<tr><td align=right>Your email address: </td><td>
	<input name="email" size=65></td></tr>
<tr><td align=right>Email subject: </td><td>
	<input name="subject" size=65></td></tr>
<tr><td align=right valign=top>Email body: </td><td>
	<textarea name="body" rows=10 cols=50></textarea></td></tr>
<tr><td>&nbsp;</td><td><input type=hidden name=BeenSubmitted value=true><br>
	<input type=submit name=submit value=submit></td></tr></table>
</form>

</body></html>