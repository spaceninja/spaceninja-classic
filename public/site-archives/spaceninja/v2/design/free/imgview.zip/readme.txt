SPACENINJA IMAGE DIRECTORY VIEWER

Requirements: PHP3

Instructions:
1. Use as the index file in a directory containing images,
and this file will display all the images in the directory
at full size, along with their filename.
