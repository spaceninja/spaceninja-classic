SPACE NINJA PHP DIRECTORY BROWSER

Requirements: PHP3

Instructions:
1. Use as the index file in any directory, and this file
	will display a list of all the files in the directory,
	along with their sizes, in kilobytes. The list is
	sortable by filename or filesize, via a link at the
	top of each row.