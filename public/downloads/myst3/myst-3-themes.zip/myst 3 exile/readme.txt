MYST 3: EXILE
Themes Readme File
------------------

INSTALLATION:
- Just unzip the file to your themes directory
  (usually C:\program files\plus!\themes).
- To use the Myst 3 StartUp and ShutDown screens,
  copy logo.sys to your root directory (C:), and 
  then copy logos.sys and logow.sys to your windows 
  directory (usually C:\windows). Be sure to make 
  backup copies of the existing files!

TO USE:
Either double click on the .theme files, or access 
the desktop themes control panel by going to your 
start menu, settings, control panel, and double click 
on "desktop themes." You should then be able to select 
one of the Myst 3 themes by selecting "other" from the 
drop-down themes menu, and navigating to the folder 
where you unzipped the themes.

WALLPAPERS:
Both of the themes wallpapers are set to 1024x768 
resolution by default. 800x600 and 1280x960 resolutions 
have also been included. To use them, just open the 
correct size in your web browser (usually by double-
clicking on it), and set it as the wallpaper by right-
clicking on the image, and choosing "set as wallpaper."

TROUBLESHOOTING:
If there is no "desktop themes" icon in your control 
panel, you'll need to install desktop theme support. 
If you have Windows 95, you'll need to install the 
Plus! package, which is sold separately from Windows. 
If you have Windows 98, ME, or 2000, here's how to 
install desktop theme support:

1. Click Start, point to Settings, and then click Control Panel.
2. Double-click Add/Remove Programs.
3. On the Windows Setup tab, check the Desktop Themes box.
4. Click OK.

LEGAL INFO:
* Themes created by Space Ninja Design (www.spaceninja.com).
* All materials copyright 2000 Preso Studios.